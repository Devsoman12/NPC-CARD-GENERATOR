with open("data/surnames.txt","r") as f:
    data = f.read().split()

with open("data/surnames_correct.txt","w") as f:
    for i in range(len(data)):
        word = list(data[i])
        for elm in word:
            if elm in [","," "]:
                word.remove(elm)
        result = "".join(word)
        f.write(result+"\n")