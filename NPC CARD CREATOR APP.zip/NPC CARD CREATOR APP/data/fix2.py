with open("data/character_quirks.txt","r") as f:
    data = f.read().splitlines()

with open("data/character_quirks_correct.txt","w") as f:
    for i in range(len(data)):
        line = list(data[i])
        result = []
        for elm in line:
            if elm != "\t":
                result.append(elm)
            else:
                break
        result = "".join(result)
        f.write(result+"\n")